from .pys2 import *

__doc__ = pys2.__doc__
if hasattr(pys2, "__all__"):
    __all__ = pys2.__all__